<?php

$outfilename = sprintf(
    "/home/s1552951/server_data/gametwo/%03d_%s_results.csv",
    (int) $_POST["participant"],
    date("Y-m-d")
);

$outfile = fopen($outfilename, "a");

fwrite(
    $outfile,
    sprintf(
        "%s,%s,%s,%s,%s\n",
        $_POST["participant"],
        $_POST["naming"],
        $_POST["matching"],
        $_POST["word"],
	$_POST["round"]
    )
);

fclose($outfile);

?>
