welcome_text = '<p class="hcentre topspace"> WHAT IS IT CALLED? <br> <br> Pictures of objects will be displayed on the screen and you will have to either select or name them. <br> <br> Your partner is already waiting for you. <br> <br> GOOD LUCK! <br> <br> Press SPACE when you are ready. </p>';
thanks2_text = '<p class="hcentre topspace"> Thanks very much for taking part! Please press any key so we can confirm your payment <p>'

var delay_text = '<p class="hcentre topspace"> We are connecting you with another player. This may take a few seconds. </p>';
var ready_text = '<p class="hcentre topspace">Done! <br> Your new partner is waiting for you. Press any key when ready. </p>';
var r2_delay_duration = 10000;

// split url for GET params
var url = window.location.href;
var params = url.match(/.*\?ppt=(.*)&r=(.*)/);
if(!params) {
    alert("No participant ID given");
}
var ppt = params[1];
var r = params[2];

var image_url_base = 'http://blake2.ppls.ed.ac.uk/~s1552951/game/pics/';

var word_pairs = {};
var filler_image_filenames = {};
var experiment_image_filenames = {};
var practice_image_filenames = {};

var correctness; // Whether naming turn was correct
var experiment_word; // Word given in initial matching trial
var naming_response; // last text response for imitation / counterimitation
var last_match;    // last matching response

var exp_pic_list;
var filler_pic_list;

var word_left = "left";
var word_right = "right";

if (r === '1') {
    exp_pic_list = "exp_pics_file_list.txt";
    filler_pic_list = "filler_pics_file_list.txt";
} else {
    exp_pic_list = "exp_pics_file_list2.txt";
    filler_pic_list = "filler_pics_file_list2.txt";
}

var correct_text = "Well done!";
var incorrect_text = "Oops! Wrong answer";

function spacer(n) {
    return '<span style="display: inline-block; width: '+n+'px">&nbsp;</span>';
}

function ImageSet(base_url, images, randomise) {
    this.base_url = base_url;
    this.images = images;
    this.bucket = [];
    this.length = images.length;
    this.randomise = randomise;
}

ImageSet.prototype.select = function() { // without replacement
    if (this.bucket.length == 0) {
        this.bucket = this.images.slice(0);
    }
    if (this.randomise) {
        return this.base_url+this.bucket.splice(Math.floor(Math.random()*this.bucket.length), 1)[0];
    } else {
        return this.base_url+this.bucket.splice(0, 1)[0];
    }
};

function get_word_pairs (data) {
    var word_pairs = {};
    var lines = data.split("\n");
    for (var idx in lines) {
        var words = lines[idx].split(";");
        word_pairs[words[0]] = words[1];
        word_pairs[words[1]] = words[0];
    }
    return word_pairs;
}

function get_image_filenames(data, prefix, suffix) {
    var images = data.split("\n");
    var images_fixed = [];
    for (var i=0; i < images.length; i++) {
        images_fixed.push(prefix+images[i]+suffix);
    }
    return images_fixed;
}

function load_data_and_run() {
    var promises = [];
    var url_path_elements = window.location.pathname.split("/");
    var url_dir = url_path_elements.slice(0,url_path_elements.length-1).join("/");
//    promises.push($.ajax({url: url_dir+"/exp_pics_alternative_names.txt"}).done(
//        function (data) { word_pairs = get_word_pairs(data); }
//    ));
    promises.push($.ajax({url: url_dir+"/"+exp_pic_list}).done(
        function (data) { experiment_image_filenames = get_image_filenames(data, "", ".jpg"); }
    ));
    promises.push($.ajax({url: url_dir+"/"+filler_pic_list}).done(
        function (data) { filler_image_filenames = get_image_filenames(data, "", ".jpg"); }
    ));
    promises.push($.ajax({url: url_dir+"/"+filler_pic_list}).done(
        function (data) { practice_image_filenames = get_image_filenames(data, "", ".jpg"); }
    ));
    $.when.apply($, promises).then(main);
}

function image_link(url, border_colour) {
    return '<img class="stimimage" src="'+url+'" style="border: 10px solid '+border_colour+'"/>';
}

function result_or_val(f, pre, post) {
    var result;
    if (f instanceof Function) {
        result = f();
    } else {
        result = f;
    }
    if (result.trim() === "") {
        return "";
    } else {
        return pre + result + post;
    }
}

function images_html(image_urlL, image_urlR, highlight, highlight_colour, feedback) {
    var colourL, colourR;
    return function () {
        var side = result_or_val(highlight, "", "");
        if (side == word_left) { colourL = highlight_colour; } else { colourL = "white"; }
        if (side == word_right) { colourR = highlight_colour; } else { colourR = "white"; }
        /*if (feedback == "") { feedback = "&nbsp;" }*/
        return '<div style="height: 8px">&nbsp;</div>'
            + spacer(64)
            + image_link(image_urlL, result_or_val(colourL, "", ""))
            + image_link(image_urlR, result_or_val(colourR, "", ""))
            + result_or_val(feedback, '<br><p class="hcentre">', "</p><br>");
    };
}

function extract_name(url) {
    var url_elements = url.split("/");
    return url_elements[url_elements.length-1].split(".")[0].replace("_dis", "");
}

function loading () {
    var duration = 1500 + Math.random() * 500;
    var loading_node = {
        type: 'single-stim',
        stimulus: '<p class="hcentre topspace">Loading ....</p>',
        is_html: true,
        timing_stim: duration,
        timing_response: duration,
        response_ends_trial: false
    };
    return loading_node;
}

function pictures_node(html, duration, data) {
    var node = {
        type: 'single-stim',
        stimulus: html,
        is_html: true,
        timing_stim: duration,
        timing_response: duration,
        response_ends_trial: false,
        //response_ends_trial: true,
        data: data
    };
    return node;
}

// experiment or filler naming node
// ppt names node, is told to wait for partner to match, then told the response is correct.
function naming_nodes (urlL, urlR, type) {
    var side;
    if (Math.random() < 0.5) {
        side = word_left;
    } else {
        var tmp1 = urlL;
        urlL = urlR;
        urlR = tmp1;
        side = word_right;
    }
    var input_node = {
        type: 'survey-text',
        questions: ["Name the picture on the "+side],
        preamble: images_html(urlL, urlR, "neither", "", ""),
        data: { image_type: type, direction: "input", input_type: "text"  }
    };
    var pause_duration = parseInt(2000 + Math.random() * 1000);
    var pause_node = {
        type: 'single-stim',
        stimulus: images_html(urlL, urlR, "neither", "", "Wait for your partner's answer"),
        is_html: true,
        timing_stim: pause_duration,
        timing_response: pause_duration,
        response_ends_trial: false,
        data: { image_type: type, direction: "pause" }
    };
    var partner_node = pictures_node(
        images_html(urlL, urlR, side, "blue", ""), 700, { image_type: type, direction: "output" }
    );
    var wait_node = pictures_node(
        images_html(urlL, urlR, side, "yellow", ""), 300, { image_type: type, direction: "output" }
    );
    var feedback_node = pictures_node(
        images_html(urlL, urlR, side, "green", correct_text), 1500, { image_type: type, direction: "output" }
    );
    return [input_node, pause_node, partner_node, wait_node, feedback_node];
}

// experiment matching node
// ppt is told to wait for partner's response, then click on picture.
// feedback depends on whether click was correct
function matching_nodes (urlL, urlR, type, word) {
    var side;
    var expected_button;
    if (Math.random() < 0.5) {
        side = word_left;
        expected_button = 0;
    } else {
        var tmp1 = urlL;
        urlL = urlR;
        urlR = tmp1;
        side = word_right;
        expected_button = 1;
    }
    var naming_node = pictures_node(
        images_html(urlL, urlR, "neither", "", "Wait for your partner's response"),
        3000 + Math.random() * 1000,
        { image_type: type, direction: "output" }
    );
    var input_node = {
        type: 'button-response',
        is_html: true,
        prompt: function () {
            return '<p class="hcentre smalltopspace">Match the image:</p><p class="hcentre">' + result_or_val(word, "", "") + '</p>'
        },
        choices: [image_link(urlL, "white"), image_link(urlR, "white")],
        data: {
            image_type: type,
            direction: "input",
            input_type: "click",
            expected_response: expected_button,
            experiment_word: result_or_val(word, "", "")
        }
    };
    var side_selected = function () { return last_match; };
    var show_selection_node = pictures_node(
        images_html(urlL, urlR, side_selected, "blue", ""), 700, { image_type: type, direction: "output" }
    );
    var wait_node = pictures_node(
        images_html(urlL, urlR, side_selected, "yellow", ""), 300, { image_type: type, direction: "output" }
    );
    var feedback = function () {
        if (side_selected() == side) {
            return correct_text;
        } else {
            return incorrect_text;
        }
    };
    var highlight_colour = function () {
        if (side_selected() == side) {
            return "green";
        } else {
            return "red";
        }
    };
    var feedback_node = pictures_node(
        images_html(urlL, urlR, side_selected, highlight_colour, feedback), 2500, { image_type: type, direction: "output" }
    );
    return [naming_node, input_node, show_selection_node, wait_node, feedback_node];
}

function hasval (x) {
    return typeof x !== 'undefined' && x !== null
}

function data_updated (data) {

    /*console.log(data);*/
    var isinput = (data.direction == "input");
    if (isinput && data.image_type === "experiment") {
        // Collect experiment word and whether it was correctly identified
        if (data.input_type === "click") {
            correctness = "INCORRECT";
            if (data.button_pressed === data.expected_response) {
                correctness = "CORRECT";
            }
            experiment_word = data.experiment_word;
            console.log("Saving response " + correctness);
        } else if (data.input_type === "text") {
            naming_response = JSON.parse(data.responses).Q0;
        }
	if (hasval(naming_response) && hasval(correctness)) {
            console.log("Saving response " + naming_response);
            var to_post = {
                participant: ppt,
                naming: naming_response,
                matching: correctness,
                word: experiment_word,
                round: r
            };
            $.ajax({
                type:'post',
                cache: false,
                url: 'record_result.php',
                data: to_post
            });
            naming_response = undefined;
            correctness = undefined;
        }
    }
    if (isinput && data.input_type == "click") {
        var last_click_idx = data.button_pressed;
        if (last_click_idx == 0) {
            last_match = word_left;
        } else {
            last_match = word_right;
        }
    }
}

function trial_set(experiment_images, filler_images, is_practice) {
    var primary_image_url;
    var repeat_image_url;
    var trials = [];
    if (is_practice) {
        primary_image_url = filler_images.select();
        repeat_image_url = filler_images.select();
    } else {
        primary_image_url = experiment_images.select();
        repeat_image_url = primary_image_url;
    }

    function or_practice(x) {
        if (is_practice) { return "practice"; } else { return x; }
    }

       // 1. Matching with experiment
        // 2. Naming filler
        // 3. Matching filler
        // 4. Naming with experiment
        trials = trials.concat(matching_nodes(
            primary_image_url,
            filler_images.select(),
            or_practice("experiment"),
            extract_name(primary_image_url)
        ));

        trials = trials.concat(naming_nodes(
            filler_images.select(),
            filler_images.select(),
            or_practice("filler")
        ));

	// Filler matching node
	var match_url_left2 = filler_images.select();
	trials = trials.concat(matching_nodes(
            match_url_left2, filler_images.select(),
            or_practice("filler"),
            extract_name(match_url_left2)
	));

	// Naming node. We don't look for a particular word, we just need to record the response
	trials = trials.concat(naming_nodes(
            repeat_image_url,
            filler_images.select(),
            or_practice("experiment")
	));

    return trials;
}

function main() {
    var trials = [];

    if (r === '1') {
        var hello_node = {
            type: 'text',
            text: welcome_text
        };
        trials.push(hello_node);
    } else {
        var delay_node = {
            type: 'single-stim',
            stimulus: delay_text,
            is_html: true,
            timing_stim: r2_delay_duration,
            timing_response: r2_delay_duration,
            response_ends_trial: false
        };
        var ready_node = {
            type: 'text',
            text: ready_text
        };
        trials.push(delay_node);
        trials.push(ready_node);
    }


    var experiment_images = new ImageSet(image_url_base, experiment_image_filenames, false);
    var filler_images = new ImageSet(image_url_base, filler_image_filenames, true);

    //for (var j=0; j<4; j++) { // practice
    //    trials = trials.concat(trial_set(null, filler_images, true));
    //}

    for (var i=0; i<experiment_images.length; i++) { // experiment
        trials = trials.concat(trial_set(experiment_images, filler_images, false));
    }


    var exit_node;
    if (r === '1') {
        exit_node = {
            type: 'text',
            text: thanks2_text
        };
    } else {
        exit_node = {
            type: 'text',
            text: thanks2_text
        };
    }

    trials.push(exit_node);

    jsPsych.init({
        display_element: $('#jspsych-target'),
        timeline: trials,
        default_iti: 0,
        on_data_update: data_updated,
         on_finish: function(){
	     if (r === '1') {
		 window.location.assign(
		     "https://app.prolific.ac/submissions/complete?cc=NB4ADBP6"
		 );
	     }
         }
    });
}

load_data_and_run();
